package calculadora;

public interface calculator {
    void setNum(int a, int b);
}
