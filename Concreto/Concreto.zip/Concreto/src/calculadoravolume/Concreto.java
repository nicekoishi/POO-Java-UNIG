package calculadoravolume;

public class Concreto {
    public static void main(String[] args) {
        Volume volume = new Volume();

        volume.setMedidas();
        volume.calcularVolume();
    }
}
